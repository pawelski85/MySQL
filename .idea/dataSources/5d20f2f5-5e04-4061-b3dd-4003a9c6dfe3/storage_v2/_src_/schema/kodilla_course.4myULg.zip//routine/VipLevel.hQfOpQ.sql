create
    definer = root@localhost function VipLevel(booksrented int) returns varchar(20)
BEGIN									                                    -- [2]
DECLARE result VARCHAR(20) DEFAULT 'Standard customer';	                -- [3]
IF booksrented >= 10 THEN						                        -- [4]
    SET result = 'Gold customer';					                        -- [5]
ELSEIF booksrented >= 5 AND booksrented < 10 THEN			            -- [6]
    SET result = 'Silver customer';				                        -- [7]
ELSEIF booksrented >= 2 AND booksrented < 5 THEN			            -- [8]
    SET result = 'Bronze customer';		           		                -- [9]
ELSE				      					                                -- [10]
    SET result = 'Standard customer';				                        -- [11]
END IF;				    				                                -- [12]
RETURN result;
END;

