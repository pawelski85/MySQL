create
    definer = root@localhost function Bestseller(monthly_booksrented int) returns tinyint(1)
BEGIN
    DECLARE result BOOL DEFAULT 0;
    IF monthly_booksrented > 2 THEN
        SET result = true;
    END IF;
    RETURN result;
END;

