create
    definer = root@localhost procedure ListBooks(IN id int)
BEGIN
    DECLARE result VARCHAR(20) DEFAULT 'wrong id';
    IF id > 0 THEN
        SELECT * FROM READERS WHERE READER_ID = id;
    ELSE
       select result;
    END IF;
END;

