create
    definer = root@localhost function VipLevel() returns varchar(20)
BEGIN
    DECLARE result VARCHAR(20) DEFAULT 'Standard customer';	-- [1]
    RETURN result;						                    -- [2]
END;

