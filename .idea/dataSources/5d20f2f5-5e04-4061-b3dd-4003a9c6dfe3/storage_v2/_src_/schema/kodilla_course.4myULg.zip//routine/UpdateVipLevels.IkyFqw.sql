create
    definer = root@localhost procedure UpdateVipLevels()
BEGIN
    DECLARE BOOKSREAD, DAYS, RDR_ID INT;				 -- [1]
    DECLARE BOOKSPERMONTH DECIMAL(5,2);				 -- [2]
    DECLARE FINISHED INT DEFAULT 0;			   	     -- [3]
    DECLARE ALL_READERS CURSOR FOR SELECT READER_ID FROM READERS;        -- [4]
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET FINISHED = 1;	            -- [5]
    OPEN ALL_READERS;			   		         	 -- [6]
    WHILE (FINISHED = 0) DO			   		         -- [7]
    FETCH ALL_READERS INTO RDR_ID;			   	 -- [8]
    IF (FINISHED = 0) THEN			   		     -- [9]
        SELECT COUNT(*) FROM RENTS			   	     -- [10]
        WHERE READER_ID = RDR_ID			     -- [11]
        INTO BOOKSREAD;			   		     -- [12]

        SELECT DATEDIFF(MAX(RENT_DATE), MIN(RENT_DATE)) + 1 FROM RENTS -- [13]
        WHERE READER_ID = RDR_ID                           		    -- [14]
        INTO DAYS;                                       	    -- [15]

        SET BOOKSPERMONTH = BOOKSREAD / DAYS * 30;              	    -- [16]

        UPDATE READERS SET VIP_LEVEL = VipLevel(BOOKSPERMONTH)		    -- [17]
        WHERE READER_ID = RDR_ID;			   		                -- [18]
        COMMIT;			   				                            -- [19]
    END IF;			   					                            -- [20]
        END WHILE;			   					                            -- [21]

    CLOSE ALL_READERS;   			   			                        -- [22]
END;

